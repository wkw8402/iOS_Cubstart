//
//  ContentView.swift
//  quizlet-ish
//
//  Created by Kun on 11/10/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        CardListView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
